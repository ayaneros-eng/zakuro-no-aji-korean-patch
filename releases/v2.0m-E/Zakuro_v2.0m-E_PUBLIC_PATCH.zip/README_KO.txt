석류의 맛 한글패치 v2.0m-E — E형 폰트 가독성 개선판

게임 ROM은 포함되어 있지 않습니다.

[일본 원본에서 적용]
1. 직접 준비한 일본 원본 ROM을 확인합니다.
   - 2,097,152 bytes / 추가 512-byte 헤더 없음
   - SHA-256: 4e0a7f639c185b49abe70de16bf7ef062a316d986753c7aabd9b98e6b956d0b6
2. BPS 호환 패처로 Zakuro_Japanese_to_v2.0m-E.bps를 적용합니다.
3. 결과 SHA-256이 아래와 같은지 확인합니다.
   f142e809f7466a1f5543c7d99678c9a7a76ccc394e352d7660df493e0dfebbc3

[기존 한글 v2.0m에서 업데이트]
- 입력 SHA-256: 9a447a967ccfe2cecb0485f3def940d8067dcfc35133a5cf5d6436784030657f
- updates/Zakuro_v2.0m_to_v2.0m-E.bps 를 적용합니다.
- 일본 원본용 BPS와 업데이트 BPS를 연속으로 둘 다 적용하지 마세요.

[Python 패처]
Python 3.8 이상 환경에서는 같은 폴더의 apply_patch.py를 사용할 수 있습니다.
자세한 옵션은 python3 apply_patch.py --help 로 확인하세요.

v2.0m-E는 기존 v2.0m의 번역·분기·엔진 코드를 유지하면서 본문/추가 UI의 한글 글리프를 E형 정자체로 교체한 가독성 개선판입니다.
전체 루트/엔딩을 E형으로 새로 전수 완주했다는 의미는 아닙니다. 검수 범위는 QA_SCOPE_KO.md를 확인하세요.
