#!/usr/bin/env python3
"""E-only patcher, Python 3.8+ standard library. No network calls or input overwrites."""
from pathlib import Path
import argparse, hashlib, json, sys, zlib
def bps(source,patch):
    if patch[:4]!=b'BPS1' or len(patch)<19:raise ValueError('Invalid BPS header')
    end=len(patch)-12
    if zlib.crc32(patch[:-4])!=int.from_bytes(patch[-4:],'little'):raise ValueError('BPS CRC mismatch')
    if zlib.crc32(source)!=int.from_bytes(patch[end:end+4],'little'):raise ValueError('Source CRC mismatch')
    p=4
    def var():
        nonlocal p
        v=0;s=1
        for _ in range(9):
            if p>=end:raise ValueError('Truncated BPS number')
            x=patch[p];p+=1;v+=(x&127)*s
            if x&128:return v
            s<<=7;v+=s
        raise ValueError('Oversized BPS number')
    sl,tl,ml=var(),var(),var()
    if sl!=len(source) or tl>32*1024*1024 or ml>end-p:raise ValueError('Invalid BPS sizes')
    p+=ml;out=bytearray();sr=tr=0
    while len(out)<tl:
        cmd=var();mode=cmd&3;n=(cmd>>2)+1;pos=len(out)
        if n>tl-pos:raise ValueError('BPS output overrun')
        if mode==0:
            if pos+n>len(source):raise ValueError('SourceRead overrun')
            out.extend(source[pos:pos+n])
        elif mode==1:
            if p+n>end:raise ValueError('TargetRead overrun')
            out.extend(patch[p:p+n]);p+=n
        elif mode==2:
            d=var();sr+=-(d>>1) if d&1 else d>>1
            if sr<0 or sr+n>len(source):raise ValueError('SourceCopy overrun')
            out.extend(source[sr:sr+n]);sr+=n
        else:
            d=var();tr+=-(d>>1) if d&1 else d>>1
            if tr<0 or tr>=pos:raise ValueError('TargetCopy overrun')
            for i in range(n):out.append(out[tr+i])
            tr+=n
    if p!=end or zlib.crc32(out)!=int.from_bytes(patch[end+4:end+8],'little'):raise ValueError('Target CRC mismatch')
    return bytes(out)
def main():
    ap=argparse.ArgumentParser(description="Zakuro v2.0m-E: Japanese original or exact Korean v2.0m -> E")
    ap.add_argument("rom",type=Path)
    ap.add_argument("--output",type=Path)
    args=ap.parse_args(); root=Path(__file__).resolve().parent
    cfg=json.loads((root/"release.json").read_text(encoding="utf-8"))
    source=args.rom.read_bytes(); digest=hashlib.sha256(source).hexdigest()
    row=next((r for r in cfg["sources"] if r["sha256"]==digest and r["size"]==len(source)),None)
    if row is None:
        raise ValueError("Unsupported ROM. Requires exact Japanese original or original Korean v2.0m. Old A/B/C/D/F/G, headered and already-patched ROMs are rejected.")
    dest=args.output or args.rom.parent/cfg["output_file"]
    if dest.resolve()==args.rom.resolve():raise ValueError("Refusing to overwrite the input ROM")
    if dest.exists():raise ValueError("Output already exists; choose a different output path")
    patch=(root/row["patch"]).read_bytes()
    if hashlib.sha256(patch).hexdigest()!=row["patch_sha256"]:raise ValueError("Patch SHA-256 mismatch")
    result=bps(source,patch)
    if len(result)!=cfg["target_size"] or hashlib.sha256(result).hexdigest()!=cfg["target_sha256"]:
        raise ValueError("Result SHA-256 or size mismatch")
    with dest.open("xb") as f:f.write(result)
    print("Created:",dest)
    print("Version:",cfg["version"],"/ font E")
    print("SHA256:",cfg["target_sha256"])
if __name__=="__main__":
    try:main()
    except (OSError,ValueError,KeyError) as exc:
        print("ERROR:",exc,file=sys.stderr);sys.exit(1)
